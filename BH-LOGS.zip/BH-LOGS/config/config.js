var config = {
  serverURL: 'http://188.246.224.251:6120' // process.env не пашет тут!!!!!
}
export default { config }



// WEBPACK FOOTER //
// src/config/config.js