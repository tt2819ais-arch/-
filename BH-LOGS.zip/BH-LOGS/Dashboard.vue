<template>
  <div class="index">
    <Header />
  </div>
</template>

<script>
import Header from '@/components/includes/Header'
export default {
  components: {
    Header
  }
}
</script>



// WEBPACK FOOTER //
// Dashboard.vue